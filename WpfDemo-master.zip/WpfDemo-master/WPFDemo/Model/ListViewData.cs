﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WPFDemo.Model
{
    public class ListViewData
    {
        public int Num { get; set; }
        public string Name { get; set; }
        public string Template { get; set; }
    }
}
