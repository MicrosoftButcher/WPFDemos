这个项目里面包含了wpf常用的控件，里面包含了自定义控件，用户控件，基本控件样式自定义的实现，另外还包含数据绑定，数据转换的实现。都是wpf基础内容。下面展示一些控件的样式：
![](https://github.com/caomfan/WpfDemo/blob/master/1.png)
![](https://github.com/caomfan/WpfDemo/blob/master/2.png)
![](https://github.com/caomfan/WpfDemo/blob/master/3.png)
